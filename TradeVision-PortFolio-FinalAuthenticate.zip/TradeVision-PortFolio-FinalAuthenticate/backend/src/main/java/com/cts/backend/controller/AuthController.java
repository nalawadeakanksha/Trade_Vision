package com.cts.backend.controller;
import com.cts.backend.entity.User;
import com.cts.backend.service.UserService;

// import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
@RequestMapping("/api/auth")
@RestController
@CrossOrigin(origins = "http://localhost:4200",allowCredentials = "true")
public class AuthController {
    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> registerUser(@RequestBody User user) {
            User registeredUser = userService.registerUser(user);
            System.out.println("Registered User: " + registeredUser);
            System.out.println("User Email: " + registeredUser.getEmail());
            //String token = jwtUtils.generateToken(registeredUser.getEmail());
            // System.out.println(token);
            // Map<String, Object> response = new HashMap<>();
            // response.put("user", registeredUser);
            // response.put("token", token);
            return ResponseEntity.status(HttpStatus.CREATED).body(registeredUser);
    }
}
