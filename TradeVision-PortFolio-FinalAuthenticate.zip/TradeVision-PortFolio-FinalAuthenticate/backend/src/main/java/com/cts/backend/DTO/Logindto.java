package com.cts.backend.DTO;

public record Logindto(String username, String password) {
}



 