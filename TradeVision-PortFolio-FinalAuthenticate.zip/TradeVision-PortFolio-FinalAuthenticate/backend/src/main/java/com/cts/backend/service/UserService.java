package com.cts.backend.service;
import com.cts.backend.entity.User;
import com.cts.backend.exception.UserAlreadyExistsException;
import com.cts.backend.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import lombok.AllArgsConstructor;
import java.util.Base64;

@Service
@AllArgsConstructor
public class UserService {
    private UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    public User registerUser(User user) {
        String decodedEmail = decode(user.getEmail());
        String decodedPhone = decode(user.getPhone());
        String decodedPassword = decode(user.getPassword());
        if (userRepository.existsByEmail(decodedEmail)) {
            throw new UserAlreadyExistsException("Email is already registered!");
        }
        System.out.println("Decoded Email: " + decodedEmail);
        user.setEmail(decodedEmail); 
        user.setPhone(decodedPhone); 
        user.setPassword(passwordEncoder.encode(decodedPassword)); 
        System.out.println("Saving user with email: " + user.getEmail()); 
        return userRepository.save(user);
    }
    private String decode(String encodedString) {
        return new String(Base64.getDecoder().decode(encodedString));
    }
}
