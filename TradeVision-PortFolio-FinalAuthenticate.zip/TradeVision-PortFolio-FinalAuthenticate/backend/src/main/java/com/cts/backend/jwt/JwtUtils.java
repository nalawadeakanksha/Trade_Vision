package com.cts.backend.jwt;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;
import java.security.Key;
import java.util.Date;

@Component
public class JwtUtils {

  // 1. In a real app, move this to application.properties: ${jwt.secret}
  private final String jwtSecret = "v9y$B&E)H@McQfTjWnZr4u7x!A%C*F-JaNdRgUkXp2s5v8y/B?E(G+KbPeShVmYq";
  private final int jwtExpirationMs = 86400000; // 24 hours

  private Key getSigningKey() {
    return Keys.hmacShaKeyFor(jwtSecret.getBytes());
  }

  public String generateToken(String email) {
    return Jwts.builder()
      .setSubject(email)
      .setIssuedAt(new Date())
      .setExpiration(new Date(System.currentTimeMillis() + jwtExpirationMs))
      .signWith(getSigningKey(), SignatureAlgorithm.HS256)
      .compact();
  }

  public String getEmailFromToken(String token) {
    return Jwts.parserBuilder()
      .setSigningKey(getSigningKey())
      .build()
      .parseClaimsJws(token)
      .getBody()
      .getSubject();
  }

  public boolean validateJwtToken(String authToken) {
    try {
      Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(authToken);
      return true;
    } catch (JwtException | IllegalArgumentException e) {
      // This will catch ExpiredJwtException, MalformedJwtException, etc.
      System.err.println("Invalid JWT: " + e.getMessage());
    }
    return false;
  }
  // You will NEED this later to validate the token on every request
//  public String getEmailFromToken(String token) {
//    return Jwts.parserBuilder()
//      .setSigningKey(getSigningKey())
//      .build()
//      .parseClaimsJws(token)
//      .getBody()
//      .getSubject();
//  }
}
