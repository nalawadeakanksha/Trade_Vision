package com.cts.backend.exception;

public class InvalidEncodingException extends RuntimeException {
    public InvalidEncodingException(String message) {
        super(message);
    }
}
