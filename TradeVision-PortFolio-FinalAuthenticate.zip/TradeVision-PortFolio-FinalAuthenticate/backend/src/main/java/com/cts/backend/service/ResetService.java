package com.cts.backend.service;

import com.cts.backend.entity.PasswordResetToken;
import com.cts.backend.repository.OtpRepository;
import com.cts.backend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Base64;

@Service
public class ResetService {
    @Autowired private UserRepository userRepository;
    @Autowired private OtpRepository otpRepository;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private JavaMailSender mailSender;

    @Transactional
    public boolean generateAndSendOtp(String encodedEmail) {
        System.out.println("Received email for OTP generation: " + encodedEmail);
        String email = decode(encodedEmail).trim().toLowerCase();
        return userRepository.findByEmailIgnoreCase(email).map(user -> {
            String otp = String.format("%04d", new SecureRandom().nextInt(10000));
            PasswordResetToken token = otpRepository.findByEmail(email).orElse(new PasswordResetToken());
            token.setEmail(email);
            token.setOtp(otp);
            token.setExpiryDate(LocalDateTime.now().plusMinutes(5));
            otpRepository.save(token);
            sendOtpEmail(email, otp);
            return true;
        }).orElse(false);
    }

    @Transactional
    public boolean finalizeReset(String eEmail, String eOtp, String ePass) {
        String email = decode(eEmail).trim().toLowerCase();
        String otp = decode(eOtp);
        String newPassword = decode(ePass);

        PasswordResetToken token = otpRepository.findByEmail(email).orElse(null);
        if (token == null || !token.getOtp().equals(otp) || token.isExpired()) return false;

        return userRepository.findByEmailIgnoreCase(email).map(user -> {
            user.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(user);
            otpRepository.deleteByEmail(email);
            return true;
        }).orElse(false);
    }

    private String decode(String encoded) {
        return new String(Base64.getDecoder().decode(encoded));
    }

    private void sendOtpEmail(String to, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject("Your OTP Code");
        message.setText("Code: " + otp);
        mailSender.send(message);
    }
}