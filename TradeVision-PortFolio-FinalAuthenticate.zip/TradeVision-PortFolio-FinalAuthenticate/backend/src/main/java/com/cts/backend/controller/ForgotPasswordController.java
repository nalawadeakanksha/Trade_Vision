package com.cts.backend.controller;

import com.cts.backend.service.ResetService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class ForgotPasswordController {

    @Autowired
    private ResetService resetService;

    @PostMapping("/forgot-password")
    public ResponseEntity<?> requestOtp(@RequestBody Map<String, String> request) {
        String email = request.get("email");
        if (resetService.generateAndSendOtp(email)) {
            return ResponseEntity.ok(Map.of("message", "OTP sent successfully"));
        }
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("message", "Email not found"));
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody Map<String, String> request) {
        boolean success = resetService.finalizeReset(
            request.get("email"), 
            request.get("otp"), 
            request.get("newPassword")
        );

        if (success) {
            return ResponseEntity.ok(Map.of("message", "Password reset successful"));
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("message", "Invalid or Expired OTP"));
    }
}