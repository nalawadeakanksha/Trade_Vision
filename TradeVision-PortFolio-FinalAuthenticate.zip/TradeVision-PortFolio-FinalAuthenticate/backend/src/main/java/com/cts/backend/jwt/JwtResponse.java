package com.cts.backend.jwt;

public record JwtResponse(String token, String username) {
}
