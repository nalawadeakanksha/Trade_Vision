package com.cts.backend.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import com.cts.backend.DTO.Logindto;
import com.cts.backend.jwt.JwtUtils;
import com.cts.backend.jwt.JwtResponse;
import com.cts.backend.service.UserService;

import java.util.Base64; // Required for decoding the Angular btoa() strings

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class LoginController {

  private final AuthenticationManager authManager;
  private final JwtUtils jwtUtils;
  private final UserService userService;

  // Constructor injection for all required beans
  public LoginController(AuthenticationManager authManager, JwtUtils jwtUtils, UserService userService) {
    this.authManager = authManager;
    this.jwtUtils = jwtUtils;
    this.userService = userService;
  }

  @PostMapping("/login")
  public ResponseEntity<?> login(@RequestBody Logindto loginRequest) {
    try {
      // 1. Decode the Base64 strings sent by Angular's btoa()
      String decodedUsername = new String(Base64.getDecoder().decode(loginRequest.username()));
      String decodedPassword = new String(Base64.getDecoder().decode(loginRequest.password()));

      System.out.println("DEBUG: Login attempt for: " + decodedUsername);

      // 2. Authenticate using the PLAIN TEXT (decoded) credentials
      // Spring Security will take this plain password and compare it with the BCrypt hash in DB
      Authentication auth = authManager.authenticate(
        new UsernamePasswordAuthenticationToken(decodedUsername, decodedPassword)
      );

      // 3. If authentication successful, generate JWT
      String token = jwtUtils.generateToken(auth.getName());

      System.out.println("---------------------");
      System.out.println("User Authenticated: " + auth.getName());
      System.out.println("Generated JWT: " + token);
      System.out.println("---------------------");

      // 4. Return the response expected by your Angular AuthService
      return ResponseEntity.ok(new JwtResponse(token, auth.getName()));

    } catch (Exception e) {
      System.out.println("DEBUG: Auth failed: " + e.getMessage());
      // Return 401 Unauthorized if decoding or authentication fails
      return ResponseEntity.status(401).body("Invalid username or password");
    }
  }
}
