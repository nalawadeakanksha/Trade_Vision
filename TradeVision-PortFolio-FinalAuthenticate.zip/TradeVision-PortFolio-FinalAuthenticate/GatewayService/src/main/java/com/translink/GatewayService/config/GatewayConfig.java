// package com.translink.GatewayService.config;

// import com.translink.GatewayService.filters.JwtAuthenticationFilter;
// import lombok.extern.slf4j.Slf4j;
// import org.springframework.cloud.gateway.route.RouteLocator;
// import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
// import org.springframework.context.annotation.Bean;
// import org.springframework.context.annotation.Configuration;

// @Slf4j
// @Configuration
// public class GatewayConfig {

//     private final JwtAuthenticationFilter authFilter;

//     public GatewayConfig(JwtAuthenticationFilter authFilter) {
//         this.authFilter = authFilter;
//     }

//     @Bean
//     public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
//         log.info("[Config] Initializing Route Definitions for BACKEND service...");

//         return builder.routes()
//                 // PUBLIC ROUTE: This covers your Login, Register, and Forgot Password controllers
//                 .route("backend_auth_public", r -> r.path("/api/auth/**")
//                         .uri("lb://BACKEND"))

//                 // SECURE ROUTE: This is a placeholder for your future controllers..
// //                .route("backend_secured", r -> r.path("/api/v1/**")
// //                        .filters(f -> f.filter(authFilter.apply(new JwtAuthenticationFilter.Config())))
// //                        .uri("lb://BACKEND"))
            

//                 .build();
                
//     }
// }

package com.translink.GatewayService.config;

import com.translink.GatewayService.filters.JwtAuthenticationFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class GatewayConfig {

    private final JwtAuthenticationFilter authFilter;

    public GatewayConfig(JwtAuthenticationFilter authFilter) {
        this.authFilter = authFilter;
    }

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        log.info("[Config] Initializing Route Definitions for BACKEND and TRADING services...");

        return builder.routes()
                // PUBLIC ROUTE: Auth service (login, register, forgot password)
                .route("backend_auth_public", r -> r.path("/api/auth/**")
                        .uri("lb://BACKEND"))

                // SECURE ROUTE: Trading microservice
                .route("trading_secured", r -> r
                        .path("/trading/**")
                        .filters(f -> f
                            .stripPrefix(1) // removes /trading so microservice receives /api/**
                            .filter(authFilter.apply(new JwtAuthenticationFilter.Config())))
                        .uri("lb://TRADING-SERVICE"))
                .build();
    }
}
