import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { catchError, throwError } from 'rxjs';

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const router = inject(Router);
  const token = localStorage.getItem('token');
  // console.log('Interceptor triggered for URL:', req.url);

  // Define your API base URL to avoid sending tokens to 3rd party domains
  const isApiUrl = req.url.includes('ltin656317.cts.com:8080');

  let authReq = req;

  // Only attach the token if it exists AND it's going to your API
  if (token && isApiUrl) {
    console.log('Token found, attaching to request...');
    authReq = req.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`
      }
    });
  }
  //  console.warn('No token found! Sending request without auth.');
  console.log('interceptor needed for login and register endpoints.');
  return next(authReq).pipe(
    catchError((error: HttpErrorResponse) => {
      // 401: Token expired or invalid
      // 403: User lacks permissions (sometimes requires a logout too)
      if ([401, 403].includes(error.status)) {
        handleAuthError(router);
      }
      
      return throwError(() => error);
    })
  );
};

// Helper function to keep the interceptor clean
const handleAuthError = (router: any) => {
  localStorage.clear(); // Clear all auth-related items
  router.navigate(['/login'], { 
    queryParams: { returnUrl: router.url } // Optional: Save where they were
  });
};