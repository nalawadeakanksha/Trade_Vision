export interface Portfolio {
  name: string;
  type: string;
  id: string;
  value: number;
  allocation: number;
  return: number;
  
}



