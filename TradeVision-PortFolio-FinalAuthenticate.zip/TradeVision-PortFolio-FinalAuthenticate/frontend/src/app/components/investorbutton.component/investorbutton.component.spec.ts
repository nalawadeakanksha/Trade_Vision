import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvestorbuttonComponent } from './investorbutton.component';

describe('InvestorbuttonComponent', () => {
  let component: InvestorbuttonComponent;
  let fixture: ComponentFixture<InvestorbuttonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InvestorbuttonComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InvestorbuttonComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
