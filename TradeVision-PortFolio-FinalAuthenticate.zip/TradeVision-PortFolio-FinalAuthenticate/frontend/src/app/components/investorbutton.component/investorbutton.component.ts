import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { Investorservice } from '../../services/investorservice';


@Component({
  selector: 'app-investorbutton',
  imports: [CommonModule,
    ReactiveFormsModule,
    InputTextModule,
    ButtonModule],
  templateUrl: './investorbutton.component.html',
  styleUrl: './investorbutton.component.scss',
})
export class InvestorbuttonComponent implements OnInit {
  form!: FormGroup;
  kycFileName: string = '';
  constructor(
    private fb: FormBuilder,
    private investorService: Investorservice,
  ) {}
  ngOnInit() {
    this.form = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      contact: ['', Validators.required],
      balance: ['', Validators.required],
      kyc: [null]
    });
  }
  get name() { return this.form.get('name'); }
  get email() { return this.form.get('email'); }
  get contact() { return this.form.get('contact'); }
  get balance() { return this.form.get('balance'); }
  onFileSelected(event: any) {
    const file = event.target.files[0];
    if (file) {
      this.kycFileName = file.name;
      this.form.patchValue({ kyc: file });
    }
  }
  
  @Output() registered = new EventEmitter<void>();
  onSubmit() {
    if (this.form.valid) {
      const investorData = { ...this.form.value };

      // ✅ Store data in service
      this.investorService.saveInvestor(investorData);
      this.registered.emit();

    } else {
      // Mark all controls touched so inline errors show
      this.form.markAllAsTouched();
    }
  }
  @Output() cancelForm = new EventEmitter<void>();
  cancel() {
    // ✅ Just clear form and file, no toast
    this.form.reset();
    this.kycFileName = '';
    this.cancelForm.emit();
  }
}
