import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MessageService } from 'primeng/api';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { AutoCompleteModule, AutoCompleteSelectEvent, AutoCompleteCompleteEvent } from 'primeng/autocomplete';
import { ToastModule } from 'primeng/toast';

interface TradeOrder {
  id: string;
  symbol: string;
  side: 'BUY' | 'SELL';
  quantity: number;
  price: number;
  status: 'Executed' | 'Pending';   // ✅ normalized for SCSS
  createdAt: string;
  displayId?: string;
}

interface Asset {
  symbol: string;
  name: string;
  price: number;
  change?: number;
  updated?: string;
}

@Component({
  selector: 'app-trading',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    InputTextModule,
    ButtonModule,
    ToastModule,
    AutoCompleteModule,
    HttpClientModule
  ],
  providers: [MessageService],
  templateUrl: './trading.component.html',
  styleUrls: ['./trading.component.scss']
})
export class TradingComponent implements OnInit, OnDestroy {
  tradeForm: FormGroup;
  recentOrders: TradeOrder[] = [];
  assets: Asset[] = [];
  filteredSymbols: Asset[] = [];
  private pollInterval: any;

  constructor(
    private fb: FormBuilder,
    private http: HttpClient,
    private messageService: MessageService,
    private cdr: ChangeDetectorRef
  ) {
    this.tradeForm = this.fb.group({
      assetSymbol: ['', Validators.required],
      orderType: ['BUY', Validators.required],
      quantity: [0, [Validators.required, Validators.min(1)]],
      price: [0, [Validators.required, Validators.min(1)]]
    });
  }

  ngOnInit() {
    this.loadAssets();
    this.loadOrders();

    // ✅ Poll every 5 seconds to auto-refresh statuses
    this.pollInterval = setInterval(() => this.loadOrders(), 5000);
  }

  ngOnDestroy() {
    if (this.pollInterval) {
      clearInterval(this.pollInterval);
    }
  }

  loadAssets() {
    this.http.get<Asset[]>('http://localhost:8085/api/assets').subscribe(data => {
      this.assets = data;
    });
  }

  loadOrders() {
    this.http.get<any[]>('http://localhost:8085/api/orders').subscribe(data => {
      this.recentOrders = data.map((o, i) => ({
        ...o,
        // ✅ normalize backend EXECUTED/PENDING → Executed/Pending
        status: o.status === 'EXECUTED' ? 'Executed' : 'Pending',
        displayId: `ORD${(i + 1).toString().padStart(3, '0')}`
      }));
      this.cdr.detectChanges();   // ✅ force Angular to refresh table
    });
  }

  filterSymbols(event: AutoCompleteCompleteEvent) {
    const query = event.query.toLowerCase();
    this.filteredSymbols = this.assets.filter(a =>
      a.symbol.toLowerCase().includes(query)
    );
  }

  onSymbolSelect(event: AutoCompleteSelectEvent) {
    const selected: Asset = event.value;
    this.tradeForm.patchValue({ assetSymbol: selected.symbol, price: selected.price });
  }

  placeOrder() {
    if (this.tradeForm.invalid) return;

    const { assetSymbol, orderType, quantity, price } = this.tradeForm.value;

    this.http.post<any>('http://localhost:8085/api/orders', {
      symbol: assetSymbol,
      side: orderType,
      quantity,
      price
    }).subscribe({
      next: order => {
        const displayId = `ORD${(this.recentOrders.length + 1).toString().padStart(3, '0')}`;
        this.recentOrders.unshift({
          ...order,
          // ✅ normalize backend EXECUTED/PENDING → Executed/Pending
          status: order.status === 'EXECUTED' ? 'Executed' : 'Pending',
          displayId
        });

        this.messageService.add({
          severity: 'success',
          summary: 'Order Placed',
          detail: `Order ${displayId} is ${order.status}`
        });

        this.tradeForm.reset({ orderType: 'BUY', quantity: 0, price: 0 });
        this.cdr.detectChanges();   // ✅ refresh after adding new order
      },
      error: err => {
        const msg = err.error?.message || 'Order failed';
        this.messageService.add({
          severity: 'error',
          summary: 'Order Failed',
          detail: msg
        });
      }
    });
  }
}
