import { Component, OnInit, inject } from '@angular/core';
import { NonNullableFormBuilder, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { AuthService } from '../../services/auth-service';
import { MessageService } from 'primeng/api';
import { ActivatedRoute } from '@angular/router'; 

// PrimeNG modules
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { CheckboxModule } from 'primeng/checkbox';
import { CardModule } from 'primeng/card';
import { ToastModule } from 'primeng/toast';
import { PasswordModule } from 'primeng/password';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    InputTextModule, 
    ButtonModule, 
    CheckboxModule, 
    CardModule, 
    ToastModule, 
    RouterLink,
    PasswordModule
  ],
  templateUrl: './login.component.html',
  styleUrl: './login.component.scss',
  providers: [MessageService]
})
export class LoginComponent implements OnInit {
  // Using inject() for modern Angular 17/18 style
  private fb = inject(NonNullableFormBuilder);
  private auth = inject(AuthService);
  private router = inject(Router);
  private messageService = inject(MessageService);
  private route = inject(ActivatedRoute);

  loading = false;
  returnUrl: string = '/dashboard';

  // Reactive Form Group
  form = this.fb.group({
    username: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required]],
    remember: [false]
  });

 ngOnInit(): void {
    // 1. UX: Fill email if saved
    const savedUser = localStorage.getItem('savedUser');
    if (savedUser) {
      this.form.patchValue({ username: savedUser, remember: true });
    }

    // 2. Logic: Get the return URL from route parameters (if the Guard sent them here)
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/dashboard';
  }

  submit(): void {
    // Stop if the form is invalid
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.loading = true;
    const { username, password, remember } = this.form.getRawValue();

    this.auth.login(username, password).subscribe({
      next: (response: any) => {
        this.loading = false;

        // // Ensure token is stored for the Guard and Interceptor
        // if (response.token) {
        //   localStorage.setItem('token', response.token);
        //   localStorage.setItem('isLoggedIn', 'true');
        // }

        // Handle "Remember Me"
        if (remember) {
          localStorage.setItem('savedUser', username);
        } else {
          localStorage.removeItem('savedUser');
        }

        this.notify('success', 'Login Successful', 'Welcome back!');
        
        // Redirect to wherever they were trying to go, or the dashboard
        setTimeout(() => {
          this.router.navigateByUrl(this.returnUrl);
        }, 1000);
      },
      error: (err: any) => {
        this.loading = false;
        const errorMsg = err.status === 401 ? 'Invalid email or password' : 'Login failed';
        this.notify('error', 'Login Failed', errorMsg);
      }
    });
  }

  private notify(severity: string, summary: string, detail: string): void {
    this.messageService.add({ severity, summary, detail });
  }
}