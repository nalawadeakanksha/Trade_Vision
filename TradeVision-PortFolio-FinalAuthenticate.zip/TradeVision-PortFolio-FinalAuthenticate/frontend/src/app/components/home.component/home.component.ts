import { Component } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { AnimateOnScrollModule } from 'primeng/animateonscroll';
import { ToolbarModule } from 'primeng/toolbar';
import { ButtonModule } from 'primeng/button';
import { RippleModule } from 'primeng/ripple';
import { MenubarModule } from 'primeng/menubar';
import { CardModule } from 'primeng/card';
import { DividerModule } from 'primeng/divider';
import { BadgeModule } from 'primeng/badge';
import { PanelModule } from 'primeng/panel';
import { RouterModule } from '@angular/router';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-home',
  imports: [
    RouterModule, 
    MenubarModule,
    ButtonModule,
    BadgeModule,
    AnimateOnScrollModule,
    
    ToolbarModule,
    ButtonModule,
    RippleModule,
    MenubarModule,
    CardModule,
    DividerModule,
    BadgeModule,
    PanelModule
  ],
  templateUrl: './home.component.html',
  styleUrl: './home.component.scss',
  providers: [MessageService]
})
export class HomeComponent {

}
