import { Component, OnInit, OnDestroy, inject, ViewChildren, QueryList, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { PasswordModule } from 'primeng/password';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { InputTextModule } from 'primeng/inputtext';
import { MessageService } from 'primeng/api';
import { ForgotPasswordService } from '../../services/forgot-password-service';

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule, 
    RouterModule, 
    PasswordModule, 
    ButtonModule, 
    ToastModule, 
    InputTextModule
  ],
  providers: [MessageService],
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit, OnDestroy {
  // Access the 4 OTP input elements for auto-focus logic
  @ViewChildren('otpInput') otpInputs!: QueryList<ElementRef>;

  private fb = inject(FormBuilder);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private forgotService = inject(ForgotPasswordService);
  private messageService = inject(MessageService);

  resetForm!: FormGroup;
  email: string = '';
  isLoading = false;
  resendLoading = false;
  
  // Tracks the visual state (null = neutral, true = green, false = red)
  otpValid: boolean | null = null; 
  otpTouched = false;
  
  secondsLeft = 30;
  canResend = false;
  private timerInterval: any;

  ngOnInit(): void {
    // 1. Extract and CLEAN email immediately to prevent "Email not found" errors
    const rawEmail = this.route.snapshot.queryParamMap.get('email') || '';
    this.email = rawEmail.trim().toLowerCase();
    
    // 2. Initialize the form with strict validation
    this.resetForm = this.fb.group({
      otp1: ['', [Validators.required, Validators.pattern('^[0-9]$')]],
      otp2: ['', [Validators.required, Validators.pattern('^[0-9]$')]],
      otp3: ['', [Validators.required, Validators.pattern('^[0-9]$')]],
      otp4: ['', [Validators.required, Validators.pattern('^[0-9]$')]],
      newPassword: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });

    this.startTimer();
  }

  ngOnDestroy(): void {
    if (this.timerInterval) clearInterval(this.timerInterval);
  }

  // Cross-field validator to ensure passwords match
  passwordMatchValidator(g: FormGroup) {
    const match = g.get('newPassword')?.value === g.get('confirmPassword')?.value;
    return match ? null : { mismatch: true };
  }

  // Handle number input and focus next box
  onOtpInput(event: any, index: number) {
    const input = event.target as HTMLInputElement;
    input.value = input.value.replace(/[^0-9]/g, '');

    if (input.value && index < 3) {
      this.otpInputs.toArray()[index + 1].nativeElement.focus();
    }
    this.validateOtpState();
  }

  // Handle backspace to focus previous box
  onOtpKeyup(event: any, index: number) {
    if (event.key === 'Backspace' && !event.target.value && index > 0) {
      this.otpInputs.toArray()[index - 1].nativeElement.focus();
    }
    this.validateOtpState();
  }

  // Allow pasting 4-digit codes
  onOtpPaste(event: ClipboardEvent) {
    const data = event.clipboardData?.getData('text');
    if (data && data.length === 4 && /^\d+$/.test(data)) {
      const digits = data.split('');
      this.resetForm.patchValue({
        otp1: digits[0],
        otp2: digits[1],
        otp3: digits[2],
        otp4: digits[3]
      });
      this.validateOtpState();
      this.otpInputs.last.nativeElement.focus();
    }
    event.preventDefault();
  }

  validateOtpState() {
    const f = this.resetForm.value;
    const otpString = (f.otp1 || '') + (f.otp2 || '') + (f.otp3 || '') + (f.otp4 || '');
    
    this.otpTouched = otpString.length > 0;
    // Set to neutral while typing, only "true" once complete
    this.otpValid = otpString.length === 4 ? true : null;
  }

  onSubmit() {
    if (this.resetForm.invalid) return;
    this.isLoading = true;

    const f = this.resetForm.value;
    const fullOtp = f.otp1 + f.otp2 + f.otp3 + f.otp4;

    this.forgotService.finalizeReset({
      email: this.email, // already trimmed in ngOnInit
      otp: fullOtp,
      newPassword: f.newPassword
    }).subscribe({
      next: (res) => {
        this.otpValid = true; 
        this.messageService.add({ 
          severity: 'success', 
          summary: 'Success', 
          detail: 'Password has been reset successfully!' 
        });
        setTimeout(() => this.router.navigate(['/login']), 2000);
      },
      error: (err) => {
        this.isLoading = false;
        this.otpValid = false; // Turn boxes RED on error
        this.messageService.add({ 
          severity: 'error', 
          summary: 'Reset Failed', 
          detail: err.error?.message || 'Invalid or Expired OTP' 
        });
      }
    });
  }

  startTimer() {
    this.secondsLeft = 30;
    this.canResend = false;
    if (this.timerInterval) clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      this.secondsLeft--;
      if (this.secondsLeft <= 0) {
        this.canResend = true;
        clearInterval(this.timerInterval);
      }
    }, 1000);
  }

  onResendOtp() {
    this.resendLoading = true;
    this.forgotService.requestOtp(this.email).subscribe({
      next: () => {
        this.resendLoading = false;
        this.messageService.add({ severity: 'info', summary: 'Sent', detail: 'New OTP sent to your email' });
        this.startTimer();
        this.otpValid = null; // Reset visual state
        this.resetForm.patchValue({otp1:'', otp2:'', otp3:'', otp4:''});
      },
      error: () => {
        this.resendLoading = false;
        this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Could not resend OTP' });
      }
    });
  }

  // Getters for template logic
  get newPassword() { return this.resetForm.get('newPassword'); }
  get confirmPassword() { return this.resetForm.get('confirmPassword'); }
}