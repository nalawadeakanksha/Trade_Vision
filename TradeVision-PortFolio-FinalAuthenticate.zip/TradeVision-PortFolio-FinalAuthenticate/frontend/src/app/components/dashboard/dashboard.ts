import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InvestorbuttonComponent } from '../investorbutton.component/investorbutton.component';
import { Investorservice, Investor } from '../../services/investorservice';
import { MetricardComponent } from '../metricard.component/metricard.component';
import { MarketOverviewComponent } from '../market-overview.component/market-overview.component';
import { TradingComponent } from '../trading.component/trading.component';
import { ComplianceComponent } from '../compliance.component/compliance.component';
import { PortfolioComponent } from '../portfolio.component/portfolio.component';
import { AnalyticsComponent } from '../analytics.component/analytics.component';
import { Router,RouterLink } from '@angular/router';

interface Metric {
  title: string;
  value: string;
}

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, InvestorbuttonComponent, MetricardComponent, MarketOverviewComponent, TradingComponent, ComplianceComponent, PortfolioComponent, AnalyticsComponent,RouterLink],
  templateUrl: './dashboard.html',
  styleUrls: ['./dashboard.scss'],
})
export class Dashboard {
  userName = 'Admin';

  tabs = ['Dashboard', 'Portfolio', 'Trading', 'Analytics', 'Compliance'];
  activeTab = 'Dashboard';

  metrics: Metric[] = [
    { title: 'Total Portfolio Value', value: '—' },
    { title: 'Total Return', value: '—' },
    { title: 'Total Assets', value: '—' },
    { title: 'Risk Score', value: '—' },
  ];

  showInvestorForm = false;
  investors: Investor[] = [];
  selectedInvestor: Investor | null = null;

  constructor(private investorService: Investorservice) {}

  ngOnInit() {
    this.loadInvestors();
    this.updateMetrics();
  }

  setTab(tab: string) {
    this.activeTab = tab;
  }

  loadInvestors() {
    this.investors = this.investorService.getInvestors();
    if (this.investors.length > 0) {
      this.selectedInvestor = this.investors[this.investors.length - 1];
      this.updateMetrics();
    } else {
      this.selectedInvestor = null;
      this.updateMetrics();
    }
  }

  registerInvestor() {
    this.showInvestorForm = true;
  }

  onInvestorAdded() {
    this.showInvestorForm = false;
    this.loadInvestors();
  }

  selectInvestor(name: string) {
    const found = this.investors.find(inv => inv.name === name);
    if (found) {
      this.selectedInvestor = found;
      this.updateMetrics();
    }
  }

  updateMetrics() {
    if (this.selectedInvestor) {
      this.metrics = [
        { title: 'Total Portfolio Value', value: '$125,000' }, // placeholder
        { title: 'Total Return', value: '+8.53%' }, // placeholder
        { title: 'Total Assets', value: '6' },      // placeholder
        { title: 'Risk Score', value: '5.3' },     // placeholder
      ];
    } else {
      this.metrics = [
        { title: 'Total Portfolio Value', value: '—' },
        { title: 'Total Return', value: '—' },
        { title: 'Total Assets', value: '—' },
        { title: 'Risk Score', value: '—' },
      ];
    }
  }
}
