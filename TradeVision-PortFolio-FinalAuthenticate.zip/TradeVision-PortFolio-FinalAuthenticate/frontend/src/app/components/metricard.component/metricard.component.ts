import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-metric-card',
  imports: [CommonModule],
  templateUrl: './metricard.component.html',
  styleUrl: './metricard.component.scss',
})
export class MetricardComponent {
  @Input() title!: string;
  @Input() value!: string;
}
