import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MetricardComponent } from './metricard.component';

describe('MetricardComponent', () => {
  let component: MetricardComponent;
  let fixture: ComponentFixture<MetricardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [MetricardComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(MetricardComponent);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
