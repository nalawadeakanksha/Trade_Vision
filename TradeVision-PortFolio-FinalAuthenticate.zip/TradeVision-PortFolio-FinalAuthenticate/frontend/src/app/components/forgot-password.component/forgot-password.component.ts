import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { ForgotPasswordService } from '../../services/forgot-password-service';

@Component({
  selector: 'app-forgot-password',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, RouterModule, InputTextModule, ButtonModule, ToastModule],
  providers: [MessageService],
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  private fb = inject(FormBuilder);
  private router = inject(Router);
  private forgotService = inject(ForgotPasswordService);
  private messageService = inject(MessageService);

  forgotPasswordForm!: FormGroup;
  isLoading = false; // Added to handle button loading state

  ngOnInit(): void {
    this.forgotPasswordForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]]
    });
  }

  get email() { return this.forgotPasswordForm.get('email'); }

  onSubmit(): void {
    if (this.forgotPasswordForm.invalid) {
      this.forgotPasswordForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;
    // Standardize email to lowercase and trim spaces
    const userEmail = this.forgotPasswordForm.value.email.trim().toLowerCase();

    this.forgotService.requestOtp(userEmail).subscribe({
      next: (res) => {
        this.isLoading = false;
        this.messageService.add({ 
          severity: 'success', 
          summary: 'OTP Sent', 
          detail: 'A 4-digit code has been sent to your email.' 
        });

        // Navigate after toast is visible
        setTimeout(() => {
          // IMPORTANT: Check if your route is '/reset-password' or '/resetpassword'
          // Standard Angular convention usually uses the hyphen.
          this.router.navigate(['/resetpassword'], { queryParams: { email: userEmail } });
        }, 1500);
      },
      error: (err) => {
        this.isLoading = false;
        console.error('OTP Request Error:', err);
        this.messageService.add({ 
          severity: 'error', 
          summary: 'Error', 
          detail: err.error?.message || 'Email not found or connection refused' 
        });
      }
    });
  }
}