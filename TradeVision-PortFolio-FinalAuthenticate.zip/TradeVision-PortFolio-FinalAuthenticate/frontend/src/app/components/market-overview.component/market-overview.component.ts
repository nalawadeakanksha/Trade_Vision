import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CardModule } from 'primeng/card'; // Import PrimeNG modules
import { ProgressBarModule } from 'primeng/progressbar';
import { ColDef, GridOptions } from 'ag-grid-community';
import { Portfolio } from '../../models/portfolio.model';
import { PortfolioCard } from '../portfolio-card/portfolio-card';
@Component({
  selector: 'app-market-overview',
  imports: [CommonModule,
    CardModule,
    ProgressBarModule,
    PortfolioCard

  ],
  templateUrl: './market-overview.component.html',
  styleUrl: './market-overview.component.scss',
})
export class MarketOverviewComponent {

  portfolios: Portfolio[] = [
    { id: 'PORT001', name: 'Growth Portfolio', type: 'EQUITY', value: 150000, allocation: 60, return: 12.5 },
    { id: 'PORT002', name: 'Stable Income', type: 'BOND', value: 62500, allocation: 25, return: 4.2 },
    { id: 'PORT003', name: 'Diversified Fund', type: 'MUTUAL FUND', value: 37500, allocation: 15, return: 8.7 }
  ];
  marketWatch = [
    { symbol: 'AAPL', name: 'Apple Inc.', price: '$175.50', change: '+2.30', percent: '+1.33%', volume: '4,56,78,900', updated: '3:59:59 pm' },
    { symbol: 'MSFT', name: 'Microsoft Corp.', price: '$350.20', change: '-1.80', percent: '-0.51%', volume: '3,24,56,780', updated: '3:59:59 pm' },
    { symbol: 'GOOGL', name: 'Alphabet Inc.', price: '$140.75', change: '+3.25', percent: '+2.36%', volume: '2,89,34,560', updated: '3:59:59 pm' },
    { symbol: 'TSLA', name: 'Tesla Inc.', price: '$245.80', change: '+5.60', percent: '+2.33%', volume: '6,54,32,100', updated: '3:59:59 pm' },
    { symbol: 'AMZN', name: 'Amazon.com Inc.', price: '$178.90', change: '-0.90', percent: '-0.50%', volume: '4,23,45,670', updated: '3:59:59 pm' },
    { symbol: 'NVDA', name: 'NVIDIA Corp.', price: '$495.30', change: '+12.40', percent: '+2.57%', volume: '5,12,34,560', updated: '3:59:59 pm' }
  ];
}















