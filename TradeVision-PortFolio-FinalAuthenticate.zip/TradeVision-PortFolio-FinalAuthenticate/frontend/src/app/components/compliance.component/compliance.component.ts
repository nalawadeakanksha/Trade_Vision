
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

@Component({
  selector: 'app-compliance',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './compliance.component.html',
  styleUrls: ['./compliance.component.scss'],
})
export class ComplianceComponent {
  rowData = [
    { reportId: 'CMP001', type: 'TRADE VOLUME', tradeVolume: '$1,45,000', riskExposure: '62.5%', status: 'Approved', generated: '31/12/2025' },
    { reportId: 'CMP002', type: 'RISK EXPOSURE', tradeVolume: '$98,000', riskExposure: '58.3%', status: 'Submitted', generated: '1/1/2026' },
    { reportId: 'CMP003', type: 'TAX REPORT', tradeVolume: '$52,000', riskExposure: '45.2%', status: 'Draft', generated: '5/1/2026' }
  ];

  getStatusClass(status: string): string {
    return `badge-${status.toLowerCase()}`;
  }

  downloadPDF() {
    const doc = new jsPDF();

    // 1. Add Title and Header Styling
    doc.setFontSize(18);
    doc.setTextColor(40, 40, 40);
    doc.text('Compliance Reports', 14, 22);
    
    doc.setFontSize(10);
    doc.setTextColor(100, 100, 100);
    doc.text('Regulatory compliance and audit trail reports', 14, 30);

    // 2. Prepare Table Data
    const head = [['Report ID', 'Type', 'Trade Volume', 'Risk Exposure', 'Status', 'Generated']];
    const data = this.rowData.map(row => [
      row.reportId,
      row.type,
      row.tradeVolume,
      row.riskExposure,
      row.status,
      row.generated
    ]);

    // 3. Generate Styled Table
    autoTable(doc, {
      head: head,
      body: data,
      startY: 40,
      theme: 'grid',
      headStyles: { 
        fillColor: [27, 27, 33], // Match your #1b1b21 dark color
        textColor: [255, 255, 255],
        fontSize: 10,
        fontStyle: 'bold'
      },
      alternateRowStyles: {
        fillColor: [245, 245, 245]
      },
      margin: { top: 40 },
      styles: {
        fontSize: 9,
        cellPadding: 5
      }
    });

    // 4. Save the PDF
    doc.save('Compliance_Report_Export.pdf');
  }
}