import { Component, ViewEncapsulation } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Portfolio } from '../../models/portfolio.model';
import { PortfolioCard } from '../portfolio-card/portfolio-card';
import { ColDef, ModuleRegistry, AllCommunityModule } from 'ag-grid-community';

// Register all community features (Filtering, Sorting, etc.)
ModuleRegistry.registerModules([AllCommunityModule]);

@Component({
  selector: 'app-portfolio',
  standalone: true,
  imports: [CommonModule, PortfolioCard],
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.scss'],

})
export class PortfolioComponent {
  // Top Portfolio Cards Data
  portfolios: Portfolio[] = [
    { id: 'PORT001', name: 'Growth Portfolio', type: 'EQUITY', value: 150000, allocation: 60, return: 12.5 },
    { id: 'PORT002', name: 'Stable Income', type: 'BOND', value: 62500, allocation: 25, return: 4.2 },
    { id: 'PORT003', name: 'Diversified Fund', type: 'MUTUAL FUND', value: 37500, allocation: 15, return: 8.7 }
  ];

  // AG Grid Row Data (Asset Holdings)
  public marketWatch = [
    { symbol: 'AAPL', name: 'Apple Inc.', Type: 'EQUITY', Quantity: 100, PurchasePrice: 150.00, CurrentPrice: 175.00, Value: 17500, Return: '+16.67%' },
    { symbol: 'MSFT', name: 'Microsoft Corp.', Type: 'EQUITY', Quantity: 150, PurchasePrice: 300.00, CurrentPrice: 350.00, Value: 52500, Return: '+16.67%' },
    { symbol: 'GOOGL', name: 'Alphabet Inc.', Type: 'EQUITY', Quantity: 80, PurchasePrice: 120.00, CurrentPrice: 140.00, Value: 11200, Return: '+16.67%' },
    { symbol: 'TSLA', name: 'Tesla Inc.', Type: 'EQUITY', Quantity: 50, PurchasePrice: 200.00, CurrentPrice: 245.00, Value: 12250, Return: '+22.50%' },
    { symbol: 'US10Y', name: 'US Treasury 10Y', Type: 'BOND', Quantity: 1000, PurchasePrice: 98.00, CurrentPrice: 102.00, Value: 102000, Return: '+4.08%' },
    { symbol: 'VFIAX', name: 'Vanguard 500 Index', Type: 'MUTUAL_FUND', Quantity: 200, PurchasePrice: 180.00, CurrentPrice: 195.00, Value: 39000, Return: '+8.33%' }
  ];

}