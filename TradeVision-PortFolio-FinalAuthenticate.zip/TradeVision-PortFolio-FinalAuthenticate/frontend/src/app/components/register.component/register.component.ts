import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators, AbstractControl, ValidationErrors, FormGroup, AsyncValidatorFn} from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
// PrimeNG + Angular modules
import { ButtonModule } from 'primeng/button';
import { PasswordModule } from 'primeng/password';
import { ReactiveFormsModule } from '@angular/forms';
import { InputTextModule } from 'primeng/inputtext';
import { CommonModule } from '@angular/common';
import { AuthService } from '../../services/auth-service';
import { Observable, of, timer } from 'rxjs';
import { map, switchMap, catchError, take } from 'rxjs/operators';
 
// ✅ Custom validator for password match
function passwordMatchValidator(group: AbstractControl): ValidationErrors | null {
  const p = group.get('password')?.value;
  const c = group.get('confirmPassword')?.value;
  return p && c && p !== c ? { passwordMismatch: true } : null;
}
 
@Component({
  selector: 'app-register',
  standalone: true,
  imports: [
    ButtonModule,
    PasswordModule,
    ReactiveFormsModule,
    InputTextModule,
    CommonModule,
    RouterLink
  ],
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss'],
})
export class RegisterComponent implements OnInit {
  form!: FormGroup;
 
  constructor(private fb: FormBuilder, private router: Router, private authService: AuthService) {}
 
  ngOnInit() {
    this.form = this.fb.group(
      {
        fullName: ['', [Validators.required]],
        email: ['', [Validators.required, Validators.email], [this.emailExistsValidator()]],
        phone: ['', Validators.required],
        company: ['', Validators.required],
        password: ['', [Validators.required, Validators.minLength(8)]],
        confirmPassword: ['', [Validators.required]],
        agreeTos: [false, [Validators.requiredTrue]],
        marketingOptIn: [false]
      },
      { validators: passwordMatchValidator }
    );
  }
   
  emailExistsValidator(): AsyncValidatorFn {
    return (control: AbstractControl): Observable<ValidationErrors | null> => {
      if (!control.value) return of(null);
      return timer(500).pipe(
        switchMap(() => this.authService.checkEmailExists(control.value)),
        map((exists) => (exists ? { alreadyRegistered: true } : null)),
        catchError(() => of(null)), // If server fails, don't block registration
        take(1)
      );
    };
  }
 

  // ✅ Typed getters for template access
  get fullName() { return this.form.get('fullName'); }
  get email() { return this.form.get('email'); }
  get phone() { return this.form.get('phone'); }
  get company() { return this.form.get('company'); }
  get password() { return this.form.get('password'); }
  get confirmPassword() { return this.form.get('confirmPassword'); }
  get agreeTos() { return this.form.get('agreeTos'); }
 
  // ✅ Submit handler
  onSubmit() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
     
      return;
    }
    const { confirmPassword, agreeTos, ...userData } = this.form.value;
    this.authService.register(userData).subscribe({
      next: (response) => {
        console.log('User registered!', response);
        alert('Registration Successful!');
        this.router.navigate(['/login']);
      },
      error: (err) => {
        if (err.status === 400 || err.status === 409) {
          this.form.get('email')?.setErrors({ alreadyRegistered: true });
        } else {
          alert('Error: ' + (err.error?.message || 'Check if Backend is running!'));
        }
      }
    });
  }
}