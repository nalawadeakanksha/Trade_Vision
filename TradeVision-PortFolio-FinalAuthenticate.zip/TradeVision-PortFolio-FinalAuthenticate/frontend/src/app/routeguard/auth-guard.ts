import { CanActivateFn } from '@angular/router';
import { inject } from '@angular/core';
import { Router } from '@angular/router';
export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  
  // 1. Check if the token exists in local storage
  console.log('Guard is checking route:', state.url);
  const token = localStorage.getItem('token');
  console.log('Token found:', !!token);

  // 2. Logic: If token exists, let them through. If not, send to login.
  if (token) {
    return true;
  } else {
    // We pass 'returnUrl' so we can send them back to where they wanted to go after they log in
    router.navigate(['/login'], { queryParams: { returnUrl: state.url } });
    return false;
  }
};