import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ForgotPasswordService {
  private http = inject(HttpClient);
  private baseUrl = 'http://localhost:8081/api/auth';

  requestOtp(email: string): Observable<any> {
    return this.http.post(`${this.baseUrl}/forgot-password`, { email: btoa(email) });
  }

  finalizeReset(payload: { email: string; otp: string; newPassword: string }): Observable<any> {
    const securePayload = {
      email: btoa(payload.email),
      otp: btoa(payload.otp),
      newPassword: btoa(payload.newPassword)
    };
    return this.http.post(`${this.baseUrl}/reset-password`, securePayload);
  }
}