import { TestBed } from '@angular/core/testing';

import { Investorservice } from './investorservice';

describe('Investorservice', () => {
  let service: Investorservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Investorservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
