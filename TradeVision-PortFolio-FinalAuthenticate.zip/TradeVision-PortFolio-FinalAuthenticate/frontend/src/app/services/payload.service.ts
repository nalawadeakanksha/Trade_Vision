import { Injectable } from '@angular/core';

@Injectable({ providedIn: 'root' })
export class PayloadService {
  toRegisterPayload(formValue: any) {
    return {
      fullName: formValue.fullName,
      email: formValue.email,
      phone: formValue.phone,
      company: formValue.company,
      password: formValue.password,
      marketingOptIn: !!formValue.marketingOptIn
    };
  }
}