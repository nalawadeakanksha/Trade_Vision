import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable, tap } from 'rxjs';
import { PayloadService } from './payload-service';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private http = inject(HttpClient);
  private payloadService = inject(PayloadService);

  // Prefer to read from environment; fallback to localhost for now
  private baseUrl = 'http://localhost:8081/api/auth';

  // Reactive auth state
  private isLoggedIn$ = new BehaviorSubject<boolean>(!!localStorage.getItem('token'));
  isLoggedIn = this.isLoggedIn$.asObservable();

  /** Register */
  register(userData: any): Observable<any> {
    const payload = this.payloadService.toRegisterPayload(userData);

    // NOTE: btoa is NOT security; only keep if backend expects base64
    payload.email = btoa(payload.email);
    payload.phone = btoa(payload.phone);
    payload.password = btoa(payload.password);

    return this.http.post<any>(`${this.baseUrl}/register`, payload);
  }

  /** Login */
  login(username: string, password: string): Observable<any> {
    const encodedUser = btoa(username);
    const encodedPass = btoa(password);

    return this.http
      .post<any>(`${this.baseUrl}/login`, {
        username: encodedUser,
        password: encodedPass,
      })
      .pipe(
        tap((response) => {
          if (response?.token) {
            this.saveSession(response.token);
          }
        })
      );
  }

  /** Check if email exists */
  checkEmailExists(email: string): Observable<boolean> {
    const params = new HttpParams().set('email', btoa(email));
    return this.http.get<boolean>(`${this.baseUrl}/check-email`, { params });
  }

  /** Send OTP for forgot password */
  sendOtp(email: string): Observable<any> {
    // If backend expects base64 here too, use: { email: btoa(email) }
    return this.http.post<any>(`${this.baseUrl}/forgot-password`, { email });
  }

  /** Reset password */
  resetPassword(payload: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/reset-password`, payload);
  }

  /** Logout */
  logout(): void {
    localStorage.removeItem('token');
    this.isLoggedIn$.next(false);
  }

  /** Simple auth check */
  isAuthenticated(): boolean {
    return !!localStorage.getItem('token');
  }

  /** Save JWT */
  private saveSession(token: string): void {
    localStorage.setItem('token', token);
    this.isLoggedIn$.next(true);
  }
}