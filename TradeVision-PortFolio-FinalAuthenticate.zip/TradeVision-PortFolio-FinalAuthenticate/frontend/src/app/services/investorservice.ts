import { Injectable } from '@angular/core';

export interface Investor {
  id: string;
  name: string;
  email: string;
  contact: string;
  balance: number;
  kyc?: File | null;
}

@Injectable({
  providedIn: 'root',
})
export class Investorservice {
  private investors: Investor[] = [];
  private idCounter = 0; // 🔑 track IDs separately

  constructor() { 
    //this.clearInvestors();
    const stored = localStorage.getItem('investors'); 
    if (stored) { 
      this.investors = JSON.parse(stored); 
      this.idCounter = this.investors.length; 
    }
  }

  private generateId(): string { 
    this.idCounter += 1; 
    return `TVPM${this.idCounter}`; 
  }

  saveInvestor(data: any) { 
    const newInvestor: Investor = { 
      ...data, id: this.generateId(), 
    }; 
    this.investors.push(newInvestor); 
    this.persist(); 
    console.log('Investor saved:', newInvestor); 
  }

  getInvestors(): Investor[] {
    return [...this.investors]; // return a copy
  }

  clearInvestors() {
    this.investors = [];
    this.idCounter = 0; // 🔑 reset ID counter
    this.persist();
    console.log('All investors cleared');
  }

  private persist() {
    localStorage.setItem('investors', JSON.stringify(this.investors));
  }
}
