import { signal } from '@angular/core';
import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
// import { Injectable } from '@angular/core';
//  import { HttpInterceptor, HttpRequest, HttpHandler } from '@angular/common/http';
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [  RouterOutlet],
    templateUrl: './app.html',
  styleUrl: './app.scss'
})
//  @Injectable()
//   export class JwtInterceptor implements HttpInterceptor 
//   { intercept(req: HttpRequest<any>, next: HttpHandler)
//      { const token = localStorage.getItem('token'); if (token)
//        { req = req.clone({ setHeaders: { Authorization: `Bearer ${token}` } }); }
//         return next.handle(req); } }
export class App {
  protected readonly title = signal('TVPM');
}





