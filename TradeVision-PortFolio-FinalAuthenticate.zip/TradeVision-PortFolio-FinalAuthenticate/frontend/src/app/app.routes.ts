import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { authGuard } from './routeguard/auth-guard';
import { Dashboard } from './components/dashboard/dashboard';
import { LoginComponent } from './components/login.component/login.component'; 
import { RegisterComponent } from './components/register.component/register.component';
import { InvestorbuttonComponent } from './components/investorbutton.component/investorbutton.component';
import { MarketOverviewComponent } from './components/market-overview.component/market-overview.component';
import { ForgotPasswordComponent } from './components/forgot-password.component/forgot-password.component';
import { TradingComponent } from './components/trading.component/trading.component';
import { ComplianceComponent } from './components/compliance.component/compliance.component';
import { HomeComponent } from './components/home.component/home.component';
import { PortfolioComponent } from './components/portfolio.component/portfolio.component';
import { AnalyticsComponent } from './components/analytics.component/analytics.component';
import { ResetPasswordComponent } from './components/reset-password.component/reset-password.component';

export const routes: Routes = [
  
  { path: '', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'resetpassword', component: ResetPasswordComponent },

  // --- Protected Routes (Requires Login) ---
  { path: 'dashboard', component: Dashboard, canActivate: [authGuard] },
  { path: 'investorbutton', component: InvestorbuttonComponent, canActivate: [authGuard] }, 
  { path: 'market', component: MarketOverviewComponent, canActivate: [authGuard] },
  { path: 'portfolio', component: PortfolioComponent, canActivate: [authGuard] },
  { path: 'trading', component: TradingComponent, canActivate: [authGuard] },
  { path: 'analytics', component: AnalyticsComponent, canActivate: [authGuard] },
  { path: 'compliance', component: ComplianceComponent, canActivate: [authGuard] },
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }















 

 

  








