import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ChartModule } from 'primeng/chart';
import { TableModule } from 'primeng/table';


@Component({
  selector: 'app-analytics',
  imports: [CommonModule, ChartModule, TableModule],
  templateUrl: './analytics.component.html',
  styleUrl: './analytics.component.scss',
})
export class AnalyticsComponent {
  // Chart Data Variables
  portfolioData: any;
  portfolioOptions: any;
  
  assetAllocationData: any;
  assetAllocationOptions: any;

  priceHistoryData: any;
  priceHistoryOptions: any;

  // Table Data
  riskMetrics!: any[];

  constructor() {}

  ngOnInit(): void {
    this.initCharts();
    this.initTableData();
  }

  initTableData() {
    this.riskMetrics = [
      { id: 'PORT001', riskScore: 7.2, roi: 12.5, volatility: '18.3%', sharpe: 0.82, generated: '6/1/2026' },
      { id: 'PORT002', riskScore: 3.1, roi: 4.2, volatility: '5.6%', sharpe: 0.45, generated: '6/1/2026' },
      { id: 'PORT003', riskScore: 5.5, roi: 8.7, volatility: '12.4%', sharpe: 0.68, generated: '6/1/2026' }
    ];
  }

  initCharts() {
    const documentStyle = getComputedStyle(document.documentElement);
    const textColor = '#ffffff';
    const textColorSecondary = '#b0b0b5';
    const surfaceBorder = '#2d2d3b';

    // 1. Portfolio Performance (Area Chart)
    this.portfolioData = {
      labels: ['Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan'],
      datasets: [
        {
          label: 'Value',
          data: [195000, 205000, 200000, 215000, 230000, 240000, 255000],
          fill: true,
          borderColor: '#a855f7', // Purple
          backgroundColor: 'rgba(168, 85, 247, 0.2)', // Semi-transparent purple
          tension: 0.4,
          pointBackgroundColor: '#a855f7',
          pointRadius: 4,
          pointHoverRadius: 6
        }
      ]
    };

    this.portfolioOptions = {
      maintainAspectRatio: false,
      aspectRatio: 0.6,
      plugins: {
        legend: { display: false },
        tooltip: {
            backgroundColor: 'rgba(20, 20, 30, 0.9)',
            titleColor: '#fff',
            bodyColor: '#a855f7',
            borderColor: '#a855f7',
            borderWidth: 1,
            callbacks: {
                label: function(context: any) {
                    return 'value : $' + context.parsed.y.toLocaleString();
                }
            }
        }
      },
      scales: {
        x: {
          ticks: { color: textColorSecondary },
          grid: { color: surfaceBorder, drawBorder: false }
        },
        y: {
          ticks: { color: textColorSecondary },
          grid: { color: surfaceBorder, drawBorder: false },
          min: 0,
          max: 260000
        }
      }
    };

    // 2. Asset Allocation (Pie Chart)
    this.assetAllocationData = {
      labels: ['Equities', 'Mutual Funds', 'Bonds'],
      datasets: [
        {
          data: [60, 15, 25],
          backgroundColor: [
            '#a855f7', // Purple
            '#7c3aed', // Darker Purple
            '#ec4899'  // Pink
          ],
          hoverBackgroundColor: ['#c084fc', '#8b5cf6', '#f472b6']
        }
      ]
    };

    this.assetAllocationOptions = {
        plugins: {
            legend: {
                labels: {
                    color: textColor,
                    usePointStyle: true
                },
                position: 'left' // Adjust position to match UI closely
            }
        }
    };

    // 3. Price History (Line Chart)
    this.priceHistoryData = {
      labels: ['2025-12-19', '2025-12-25', '2025-12-31', '2026-01-06', '2026-01-14'],
      datasets: [
        {
          label: 'Price',
          data: [150, 155, 160, 165, 172],
          borderColor: '#ec4899', // Pink
          tension: 0.4,
          pointRadius: 0, // Hide points for clean line look
          borderWidth: 2,
          fill: false
        }
      ]
    };

    this.priceHistoryOptions = {
      maintainAspectRatio: false,
      aspectRatio: 0.6,
      plugins: {
        legend: { display: false }
      },
      scales: {
        x: {
            ticks: { color: textColorSecondary, font: {size: 10} },
            grid: { color: surfaceBorder, drawBorder: false,  borderDash: [5, 5] }
        },
        y: {
            ticks: { color: textColorSecondary },
            grid: { color: surfaceBorder, drawBorder: false, borderDash: [5, 5] },
            min: 0,
            max: 180
        }
      }
    };
  }
}
