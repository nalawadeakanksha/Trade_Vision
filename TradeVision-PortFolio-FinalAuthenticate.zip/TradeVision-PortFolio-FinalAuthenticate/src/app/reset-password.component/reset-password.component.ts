import { Component, ElementRef, QueryList, ViewChildren, inject, OnDestroy, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AbstractControl, FormBuilder, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { MessageService } from 'primeng/api';

import { ToastModule } from 'primeng/toast';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { PasswordModule } from 'primeng/password';

import { AuthService } from '../auth-service';

function passwordMatch(group: AbstractControl): ValidationErrors | null {
  const p = group.get('newPassword')?.value;
  const c = group.get('confirmPassword')?.value;
  if (!p || !c) return null;
  return p === c ? null : { mismatch: true };
}

@Component({
  selector: 'app-reset-password',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, ToastModule, InputTextModule, ButtonModule, PasswordModule, RouterLink],
  providers: [MessageService],
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit, OnDestroy {
  private fb = inject(FormBuilder);
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private toast = inject(MessageService);
  private auth = inject(AuthService);

  // ✅ valid OTP for now
  private readonly VALID_OTP = '1234';

  email = '';
  isLoading = false;
  resendLoading = false;

  // ✅ OTP UI state
  otpTouched = false;
  otpValid: boolean | null = null; // null until 4 digits are filled

  // ✅ Resend timer
  resendCooldownSeconds = 30;
  secondsLeft = 0;
  private timerId: any = null;

  @ViewChildren('otpInput') otpInputs!: QueryList<ElementRef<HTMLInputElement>>;

  resetForm = this.fb.group(
    {
      otp1: ['', [Validators.required, Validators.pattern(/^\d$/)]],
      otp2: ['', [Validators.required, Validators.pattern(/^\d$/)]],
      otp3: ['', [Validators.required, Validators.pattern(/^\d$/)]],
      otp4: ['', [Validators.required, Validators.pattern(/^\d$/)]],
      newPassword: ['', [Validators.required, Validators.minLength(8)]],
      confirmPassword: ['', [Validators.required]]
    },
    { validators: passwordMatch }
  );

  get newPassword() { return this.resetForm.get('newPassword'); }
  get confirmPassword() { return this.resetForm.get('confirmPassword'); }

  ngOnInit(): void {
    this.email = this.route.snapshot.queryParamMap.get('email') || '';

    if (!this.email) {
      this.toast.add({ severity: 'error', summary: 'Error', detail: 'Email missing. Try again.', life: 3000 });
      this.router.navigate(['/forgot-password']);
      return;
    }

    // ✅ Start timer when screen loads
    this.startResendTimer();
  }

  ngOnDestroy(): void {
    this.clearTimer();
  }

  /**
   * ✅ SINGLE SOURCE OF TRUTH for OTP:
   * - reads latest values
   * - trims
   * - keeps only digits
   */
  get enteredOtp(): string {
    const v = this.resetForm.getRawValue();
    return [v.otp1, v.otp2, v.otp3, v.otp4]
      .map(x => (x ?? '').toString().trim())
      .join('')
      .replace(/\D/g, '');
  }

  /**
   * ✅ OTP validity derived ONLY from enteredOtp
   */
  validateOtpInstant(): void {
    this.otpTouched = true;

    const otp = this.enteredOtp;

    // neutral until exactly 4 digits
    if (otp.length !== 4) {
      this.otpValid = null;
      return;
    }

    this.otpValid = (otp === this.VALID_OTP);

    // Debug (optional)
    // console.log('enteredOtp:', otp, 'otpValid:', this.otpValid);
  }





  onOtpInput(event: Event, index: number): void {
  this.otpTouched = true;

  const input = event.target as HTMLInputElement;

  // keep only digits
  let val = (input.value || '').replace(/\D/g, '');

  // ✅ If user/autofill inserts multiple digits, spread them across 4 boxes
  if (val.length > 1) {
    val = val.slice(0, 4);
    const d = val.split('');

    this.resetForm.patchValue(
      {
        otp1: d[0] || '',
        otp2: d[1] || '',
        otp3: d[2] || '',
        otp4: d[3] || ''
      },
      { emitEvent: false }
    );

    // update UI inputs too
    const inputs = this.otpInputs?.toArray() || [];
    for (let i = 0; i < 4; i++) {
      if (inputs[i]) inputs[i].nativeElement.value = d[i] || '';
    }

    this.focusOtp(Math.min(val.length, 4) - 1);
    this.validateOtpInstant();
    return;
  }

  // ✅ Single digit typing case
  val = val.slice(-1);
  input.value = val;

  const controlName = `otp${index + 1}` as 'otp1' | 'otp2' | 'otp3' | 'otp4';
  this.resetForm.get(controlName)?.setValue(val, { emitEvent: false });

  if (val && index < 3) {
    this.focusOtp(index + 1);
  }

  this.validateOtpInstant();
}
  // ✅ Move focus and accept only digits
  onOtpKeyup(event: KeyboardEvent, index: number): void {
    this.otpTouched = true;

    const input = event.target as HTMLInputElement;

    // keep only last digit typed
    const clean = (input.value || '').replace(/\D/g, '').slice(-1);
    input.value = clean;

    const controlName = `otp${index + 1}` as 'otp1' | 'otp2' | 'otp3' | 'otp4';
    // avoid form/event timing issues
    this.resetForm.get(controlName)?.setValue(clean, { emitEvent: false });

    if (event.key === 'Backspace') {
      if (!clean && index > 0) this.focusOtp(index - 1);
      this.validateOtpInstant();
      return;
    }

    if (clean && index < 3) this.focusOtp(index + 1);

    this.validateOtpInstant();
  }

  // ✅ Paste support (paste 1234)
  onOtpPaste(event: ClipboardEvent): void {
    event.preventDefault();
    const pasted = (event.clipboardData?.getData('text') || '').replace(/\D/g, '').slice(0, 4);
    if (!pasted) return;

    const d = pasted.split('');

    // patch form values without triggering extra events
    this.resetForm.patchValue(
      {
        otp1: d[0] || '',
        otp2: d[1] || '',
        otp3: d[2] || '',
        otp4: d[3] || ''
      },
      { emitEvent: false }
    );

    // also update input UI values (to avoid any mismatch)
    const inputs = this.otpInputs?.toArray() || [];
    for (let i = 0; i < 4; i++) {
      if (inputs[i]) inputs[i].nativeElement.value = d[i] || '';
    }

    this.otpTouched = true;
    this.validateOtpInstant();
    this.focusOtp(Math.min(pasted.length, 4) - 1);
  }

  private focusOtp(index: number): void {
    const el = this.otpInputs?.get(index)?.nativeElement;
    if (el) {
      el.focus();
      el.select();
    }
  }

  // ✅ Timer helpers
  private startResendTimer(): void {
    this.secondsLeft = this.resendCooldownSeconds;
    this.clearTimer();

    this.timerId = setInterval(() => {
      this.secondsLeft--;
      if (this.secondsLeft <= 0) this.clearTimer();
    }, 1000);
  }

  private clearTimer(): void {
    if (this.timerId) {
      clearInterval(this.timerId);
      this.timerId = null;
    }
  }

  get canResend(): boolean {
    return this.secondsLeft === 0 && !this.resendLoading;
  }

  // ✅ Resend OTP click
  onResendOtp(): void {
    if (!this.canResend) return;

    this.resendLoading = true;
    this.auth.sendOtp(this.email).subscribe({
      next: (res) => {
        this.toast.add({ severity: 'success', summary: 'OTP Resent', detail: res.message, life: 3000 });
        this.startResendTimer();
      },
      error: (err) => {
        this.toast.add({
          severity: 'error',
          summary: 'Error',
          detail: err?.error?.message || 'Failed to resend OTP',
          life: 3000
        });
      },
      complete: () => (this.resendLoading = false)
    });
  }

  // ✅ Submit
  onSubmit(): void {
    this.validateOtpInstant();

    // ✅ validate using the same enteredOtp
    const otp = this.enteredOtp;

    if (otp !== this.VALID_OTP) {
      this.otpValid = false;
      this.toast.add({ severity: 'error', summary: 'Invalid OTP', detail: 'Please enter correct OTP.', life: 3000 });
      return;
    }

    if (this.resetForm.invalid) {
      this.resetForm.markAllAsTouched();
      return;
    }

    this.isLoading = true;

    this.auth.resetPassword({
      email: this.email,
      otp: otp, // ✅ use same otp variable
      newPassword: this.resetForm.value.newPassword!
    }).subscribe({
      next: (res) => {
        this.isLoading = false;

        // ✅ toast unchanged
        this.toast.add({
          severity: 'success',
          summary: 'Success',
          detail: res.message || 'Password reset successful',
          life: 1500
        });

        // ✅ redirect after 1–2 seconds
        setTimeout(() => {
          this.router.navigate(['/login']);
          // If you want Signup page instead, change to:
          // this.router.navigate(['/signup']);
        }, 1200);
      },
      error: (err) => {
        this.isLoading = false;

        this.toast.add({
          severity: 'error',
          summary: 'Error',
          detail: err?.error?.message || 'Reset failed',
          life: 3000
        });
      }
    });
  }
}