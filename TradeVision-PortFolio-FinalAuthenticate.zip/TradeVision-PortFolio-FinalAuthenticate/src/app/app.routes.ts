import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Dashboard } from './dashboard/dashboard';
import { LoginComponent } from './login.component/login.component'; 
import { RegisterComponent } from './register.component/register.component';
import { InvestorbuttonComponent } from './investorbutton.component/investorbutton.component';
import { MarketOverviewComponent } from './market-overview.component/market-overview.component';
import { ForgotPasswordComponent } from './forgot-password.component/forgot-password.component';
import { TradingComponent } from './trading.component/trading.component';
import { ComplianceComponent } from './compliance.component/compliance.component';
import { HomeComponent } from './home.component/home.component';
import { PortfolioComponent } from './portfolio.component/portfolio.component';
import { AnalyticsComponent } from './analytics.component/analytics.component';
import { ResetPasswordComponent } from './reset-password.component/reset-password.component';
export const routes: Routes = [
  {path: '', component: HomeComponent },
  {path:'login', component: LoginComponent },
  {path: 'register', component: RegisterComponent },
  {path: 'forgot-password', component: ForgotPasswordComponent },
  { path: 'reset-password', component: ResetPasswordComponent },
  {path: 'dashboard', component: Dashboard},
  {path: 'investorbutton', component: InvestorbuttonComponent}, 
  {path: 'market', component:MarketOverviewComponent},
  {path: 'portfolio', component: PortfolioComponent},
  {path: 'trading', component: TradingComponent },
  {path: 'analytics', component: AnalyticsComponent},
  {path: 'compliance', component: ComplianceComponent},
  
]
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }












  
  








