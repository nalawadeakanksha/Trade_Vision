import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { delay } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  private dummyUser = 'admin';
  private dummyPass = 'password123';

  // Toggle mock mode now; later connect backend by replacing mock methods
  private useMock = true;

  login(user: string, pass: string): boolean {
    return user === this.dummyUser && pass === this.dummyPass;
  }

  // ✅ Screen 1: Send OTP (mock)
  sendOtp(email: string): Observable<{ message: string }> {
    if (this.useMock) {
      return of({ message: `OTP sent to ${email} (mock). Use OTP: 123456` }).pipe(delay(800));
    }
    // Later: return this.http.post(...)
    return of({ message: 'Not implemented' });
  }

  // ✅ Screen 2: Reset password (mock)
  resetPassword(payload: { email: string; otp: string; newPassword: string }): Observable<{ message: string }> {
    if (this.useMock) {
      if (payload.otp !== '1234') {
        return throwError(() => ({ error: { message: 'Invalid OTP (mock). Try 123456' } }));
      }
      return of({ message: 'Password reset successful (mock)' }).pipe(delay(800));
    }
    // Later: return this.http.post(...)
    return of({ message: 'Not implemented' });
  }
}