import { Component, input } from '@angular/core';
import { Portfolio } from '../../portfolio.model';
import { CardModule } from 'primeng/card'; // Required for p-card
import { ProgressBarModule } from 'primeng/progressbar';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-portfolio-card',
  imports: [CardModule, ProgressBarModule, CommonModule],
  templateUrl: './portfolio-card.html',
  styleUrl: './portfolio-card.scss',
})
export class PortfolioCard {
  data = input.required<Portfolio>();
}
